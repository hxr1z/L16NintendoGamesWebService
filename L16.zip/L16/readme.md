Web Service Primary Url:
https://l16nintendogameswebservice.onrender.com

Retrieve all games:
https://l16nintendogameswebservice.onrender.com/allgames

Add game:
https://l16nintendogameswebservice.onrender.com/addgame

{
"game_title": "The Legend of Zelda: Tears of the Kingdom",
"description": "An epic adventure across the land and skies of Hyrule."
}

Update game:
https://l16nintendogameswebservice.onrender.com/updategame/1

{
"game_title": "The Legend of Zelda: BotW",
"description": "The precursor to Tears of the Kingdom set in a vast open world."
}

Delete game using GET:
https://l16nintendogameswebservice.onrender.com/deletegame/2

Delete game using POST:
https://l16nintendogameswebservice.onrender.com/deletegame